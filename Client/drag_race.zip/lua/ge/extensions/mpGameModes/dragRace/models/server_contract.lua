require('ge/extensions/mpGameModes/dragRace/util/enum')

RaceType = enum({'MP', 'SP', 'none'})
PlayerStatus = enum({'prestaging', 'ready', 'racing', 'disqualified', 'none'})
