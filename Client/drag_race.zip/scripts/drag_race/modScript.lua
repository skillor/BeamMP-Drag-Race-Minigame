load("mpGameModes/dragRace/dragRace")
registerCoreModule("mpGameModes/dragRace/dragRace")
