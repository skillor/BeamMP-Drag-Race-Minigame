game -> launcher
launcher get resource list
launcher download resources, update client ui at same time
once files downloaded
launcher -> game (ready)
game load level
game -> launcher -> server
server --> game to spawn all vehicles
game create all vehicles and the vehiclesMap

A - Game -> Launcher Connection + keep alive
B - Receive Servers
C -
D -
E -
F
G
H
I
J
K
L
M
N
O
P
Q
R
S
T
U - UI update message (Non In Game)
V
W
X
Y
Z
